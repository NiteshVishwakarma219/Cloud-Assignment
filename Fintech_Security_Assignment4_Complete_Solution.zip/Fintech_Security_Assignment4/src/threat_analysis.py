"""Analyse simulated security events and create a text report plus CSV summary."""
import json, csv
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOG = ROOT / 'data' / 'Threat_Log.json'
OUT = ROOT / 'output'
THRESHOLD = 5  # flag IPs with more than five failed logins

def main():
    OUT.mkdir(exist_ok=True)
    events = json.loads(LOG.read_text(encoding='utf-8'))
    failed_by_ip = Counter(e.get('source_ip','unknown') for e in events if e.get('event') == 'login_failed')
    denied_by_ip = Counter(e.get('source_ip','unknown') for e in events if e.get('event') == 'api_access_denied')
    rate_by_ip = Counter(e.get('source_ip','unknown') for e in events if e.get('event') == 'request_rate_high')
    suspicious = {ip: n for ip,n in failed_by_ip.items() if n > THRESHOLD}
    lines = ['FINTECH SECURITY - SIMULATED THREAT ANALYSIS', '='*48,
             f'Total events analysed: {len(events)}',
             f'Failed login events: {sum(failed_by_ip.values())}',
             f'Access-denied events: {sum(denied_by_ip.values())}',
             f'Rate-limit events: {sum(rate_by_ip.values())}', '', 'Findings:']
    if suspicious:
        for ip,n in suspicious.items():
            lines.append(f'[HIGH] {ip}: {n} failed logins (> {THRESHOLD}); recommend temporary block/rate limit and investigate.')
    else:
        lines.append('[INFO] No IP crossed the failed-login threshold.')
    for ip,n in denied_by_ip.items():
        lines.append(f'[MEDIUM] {ip}: {n} access-denied events; review role permissions and audit context.')
    for ip,n in rate_by_ip.items():
        lines.append(f'[MEDIUM] {ip}: {n} rate-limit events; keep throttling enabled and monitor.')
    lines += ['', 'Important: source IPs are documentation-only TEST-NET addresses; findings are simulated, not live threat intelligence.']
    (OUT/'threat_analysis.txt').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    with (OUT/'threat_summary.csv').open('w', newline='', encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['source_ip','failed_logins','access_denied','rate_limit_events','flagged'])
        ips=sorted(set(failed_by_ip)|set(denied_by_ip)|set(rate_by_ip))
        for ip in ips: w.writerow([ip,failed_by_ip[ip],denied_by_ip[ip],rate_by_ip[ip],str(failed_by_ip[ip]>THRESHOLD).lower()])
    print('\n'.join(lines))
    print(f'\nSaved: {OUT / "threat_analysis.txt"} and {OUT / "threat_summary.csv"}')
if __name__ == '__main__': main()
