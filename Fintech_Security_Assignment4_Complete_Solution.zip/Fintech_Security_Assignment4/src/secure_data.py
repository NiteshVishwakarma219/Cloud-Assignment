"""Encrypt a transaction CSV with an AWS KMS data key (envelope encryption).

AWS mode uses KMS GenerateDataKey and AES-256-GCM locally. The encrypted payload
and encrypted data key are saved together. This is a small-file demo, not a
production key-management library. Do not commit real financial data or secrets.
"""
import argparse, base64, json, os
from pathlib import Path
import boto3
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

ROOT = Path(__file__).resolve().parents[1]

def encrypt_file(input_path: Path, output_path: Path, key_id: str, region: str):
    kms = boto3.client('kms', region_name=region)
    response = kms.generate_data_key(KeyId=key_id, KeySpec='AES_256')
    plaintext_key = response['Plaintext']
    encrypted_key = response['CiphertextBlob']
    nonce = os.urandom(12)
    plaintext = input_path.read_bytes()
    ciphertext = AESGCM(plaintext_key).encrypt(nonce, plaintext, None)
    payload = {'format':'AES-256-GCM + AWS KMS envelope encryption',
               'key_id':key_id,
               'encrypted_data_key_b64':base64.b64encode(encrypted_key).decode('ascii'),
               'nonce_b64':base64.b64encode(nonce).decode('ascii'),
               'ciphertext_b64':base64.b64encode(ciphertext).decode('ascii')}
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2), encoding='utf-8')
    # best effort overwrite reference; Python cannot guarantee memory zeroisation
    del plaintext_key
    print(f'Encrypted {input_path.name} -> {output_path}')
    print('Data encryption: AES-256-GCM; data key encrypted by AWS KMS.')

def decrypt_file(input_path: Path, output_path: Path, region: str):
    payload=json.loads(input_path.read_text(encoding='utf-8'))
    kms=boto3.client('kms', region_name=region)
    encrypted_key=base64.b64decode(payload['encrypted_data_key_b64'])
    key=kms.decrypt(CiphertextBlob=encrypted_key)['Plaintext']
    nonce=base64.b64decode(payload['nonce_b64'])
    ciphertext=base64.b64decode(payload['ciphertext_b64'])
    plaintext=AESGCM(key).decrypt(nonce,ciphertext,None)
    output_path.parent.mkdir(parents=True,exist_ok=True); output_path.write_bytes(plaintext)
    del key
    print(f'Decrypted file written to {output_path}')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['encrypt','decrypt'])
    p.add_argument('--input',type=Path,default=ROOT/'data'/'Customer_Transactions.csv')
    p.add_argument('--output',type=Path,default=ROOT/'output'/'Customer_Transactions.encrypted.json')
    p.add_argument('--key-id',default=os.getenv('KMS_KEY_ID','alias/fintech-assignment-key'))
    p.add_argument('--region',default=os.getenv('AWS_REGION','ap-south-1'))
    args=p.parse_args()
    if args.action=='encrypt': encrypt_file(args.input,args.output,args.key_id,args.region)
    else: decrypt_file(args.input,args.output,args.region)
if __name__=='__main__': main()
