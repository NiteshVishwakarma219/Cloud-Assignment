"""Local demonstration API: JWT authentication and role-based authorization.
Demo users/passwords are intentionally simple and must never be reused in production.
"""
import os, csv, secrets
from functools import wraps
from pathlib import Path
from flask import Flask, request, jsonify
import jwt
from datetime import datetime, timedelta, timezone

ROOT=Path(__file__).resolve().parents[1]
app=Flask(__name__)
app.config['JWT_SECRET']=os.getenv('JWT_SECRET','DEMO-ONLY-change-this-secret-before-use')
# Demonstration-only identities; production should use a managed identity provider,
# salted password hashes, MFA, secret storage, rotation, and audit logging.
USERS={
 'admin1': {'password':'AdminDemo!23','role':'Admin'},
 'analyst1': {'password':'AnalystDemo!23','role':'Analyst'},
 'viewer1': {'password':'ViewerDemo!23','role':'Viewer'}
}
ROLE_LEVEL={'Viewer':1,'Analyst':2,'Admin':3}
def token_required(fn):
 @wraps(fn)
 def wrapper(*args,**kwargs):
  auth=request.headers.get('Authorization','')
  if not auth.startswith('Bearer '): return jsonify(error='Bearer token required'),401
  try: claims=jwt.decode(auth[7:],app.config['JWT_SECRET'],algorithms=['HS256'])
  except jwt.ExpiredSignatureError: return jsonify(error='Token expired'),401
  except jwt.InvalidTokenError: return jsonify(error='Invalid token'),401
  request.identity=claims
  return fn(*args,**kwargs)
 return wrapper
def role_required(min_role):
 def decorator(fn):
  @wraps(fn)
  @token_required
  def wrapper(*args,**kwargs):
   role=request.identity.get('role','')
   if ROLE_LEVEL.get(role,0)<ROLE_LEVEL[min_role]: return jsonify(error='Insufficient role',required=min_role),403
   return fn(*args,**kwargs)
  return wrapper
 return decorator
@app.get('/health')
def health(): return jsonify(status='ok',mode='local-demo')
@app.post('/login')
def login():
 data=request.get_json(silent=True) or {}
 user=USERS.get(str(data.get('username','')))
 if not user or not secrets.compare_digest(str(data.get('password','')),user['password']):
  return jsonify(error='Invalid credentials'),401
 now=datetime.now(timezone.utc)
 token=jwt.encode({'sub':data['username'],'role':user['role'],'iat':now,'exp':now+timedelta(minutes=30)},app.config['JWT_SECRET'],algorithm='HS256')
 return jsonify(access_token=token,token_type='Bearer',expires_in=1800,role=user['role'])
@app.get('/transactions')
@role_required('Analyst')
def transactions():
 path=ROOT/'data'/'Customer_Transactions.csv'
 with path.open(newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
 # Demo data contains references, not actual customer names or account numbers.
 return jsonify(count=len(rows),transactions=rows)
@app.get('/admin/audit')
@role_required('Admin')
def audit():
 path=ROOT/'output'/'threat_analysis.txt'
 return jsonify(report=path.read_text(encoding='utf-8') if path.exists() else 'Run src/threat_analysis.py first.')
@app.errorhandler(404)
def not_found(_): return jsonify(error='Not found'),404
if __name__=='__main__':
 # Local-only; use HTTPS reverse proxy/API Gateway and managed secrets for deployment.
 app.run(host='127.0.0.1',port=5000,debug=False)
