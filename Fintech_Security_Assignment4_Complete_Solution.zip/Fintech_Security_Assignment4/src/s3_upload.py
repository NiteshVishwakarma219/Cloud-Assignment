"""Upload the encrypted output to a private S3 bucket using boto3."""
import argparse, os
from pathlib import Path
import boto3
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=argparse.ArgumentParser()
    p.add_argument('--file',type=Path,default=ROOT/'output'/'Customer_Transactions.encrypted.json')
    p.add_argument('--bucket',default=os.getenv('S3_BUCKET',''))
    p.add_argument('--region',default=os.getenv('AWS_REGION','ap-south-1'))
    a=p.parse_args()
    if not a.bucket: raise SystemExit('Set S3_BUCKET to your own private bucket name before running.')
    if not a.file.exists(): raise SystemExit(f'File not found: {a.file}. Run secure_data.py encrypt first.')
    s3=boto3.client('s3',region_name=a.region)
    s3.upload_file(str(a.file),a.bucket,'encrypted/Customer_Transactions.encrypted.json',ExtraArgs={'ServerSideEncryption':'aws:kms'})
    print('Upload request completed. Verify the object and encryption settings in the S3 console.')
if __name__=='__main__': main()
