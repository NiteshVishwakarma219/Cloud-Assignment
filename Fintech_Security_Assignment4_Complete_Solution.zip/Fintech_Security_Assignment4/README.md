# Fintech Cloud Security Solution — Modular Assignment 4

## 1. What this prototype demonstrates
This project addresses the assignment scenario of protecting a fintech transaction platform from unauthorised access, data leakage and API misuse. It includes the two required student-created datasets, a small Flask API with JWT login and role checks, AWS KMS envelope-encryption code, a private-S3 upload script, a simulated threat-log analyser, and an architecture diagram.

**Important scope note:** the API and threat analysis can be demonstrated locally. KMS/S3 steps require an AWS account, configured credentials, a KMS key and a private bucket. They are not claimed as deployed unless you run them and capture your own AWS evidence.

## 2. Folder layout
- `data/Customer_Transactions.csv` — simulated transaction records; no real customer information.
- `data/Threat_Log.json` — simulated authentication and API events using documentation-only IP addresses.
- `src/app.py` — login endpoint, JWT validation and role-based endpoints.
- `src/secure_data.py` — AES-256-GCM encryption with an AWS KMS-generated data key.
- `src/s3_upload.py` — uploads encrypted output to S3 using SSE-KMS.
- `src/threat_analysis.py` — flags more than five failed logins from one IP and writes a text/CSV summary.
- `docs/architecture.svg` — architecture diagram.
- `output/` — generated analysis output and encrypted file location.

## 3. Run locally on Windows PowerShell
From the project folder:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python src\threat_analysis.py
python -m compileall src
python src\app.py
```
Open another PowerShell window to test the API:
```powershell
$body = @{ username = 'analyst1'; password = 'AnalystDemo!23' } | ConvertTo-Json
$login = Invoke-RestMethod -Method Post -Uri http://127.0.0.1:5000/login -ContentType 'application/json' -Body $body
$token = $login.access_token
Invoke-RestMethod -Uri http://127.0.0.1:5000/transactions -Headers @{ Authorization = "Bearer $token" }
```
Check role restrictions: login as `viewer1` / `ViewerDemo!23`, then request `/transactions`; the expected result is HTTP 403. A request without a token should return HTTP 401. Login as `admin1` / `AdminDemo!23` and call `/admin/audit` after running the analyser.

These credentials and the hard-coded demo user store are for a local assignment only. Do not expose this service to the internet or use these patterns for a real fintech service. A production implementation should use a managed identity provider, salted password hashes, MFA, rate limiting, secret storage, HTTPS, validation, monitoring, and audited least-privilege roles.

## 4. AWS KMS and S3 demonstration
1. In AWS Console, select `ap-south-1` (or change `AWS_REGION`). Create a symmetric KMS key for encrypt/decrypt use. Create a private S3 bucket with Block Public Access enabled and default SSE-KMS encryption. Do not enable public access.
2. Configure AWS CLI credentials using an IAM identity (prefer a temporary role/SSO, not root credentials). Grant only required `kms:GenerateDataKey`, `kms:Decrypt` and S3 upload permissions for this demo. Do not put access keys in code or commit them.
3. Copy `.env.example` values into your terminal session/environment and set `KMS_KEY_ID` to your key ID/alias and `S3_BUCKET` to your bucket name.
4. Run:
```powershell
python src\secure_data.py encrypt
python src\secure_data.py decrypt --input output\Customer_Transactions.encrypted.json --output output\Customer_Transactions.restored.csv
python src\s3_upload.py
```
5. Verify the object in S3 and capture a screenshot of the object properties showing server-side encryption. Capture only genuine output from your own account.

KMS encrypts the data key; AES-256-GCM encrypts the CSV contents. The encrypted data key is stored with the ciphertext, so decrypt permission is required to recover the data key. The script is a small-file teaching example, not a certified production cryptographic module.

## 5. Threat analysis rules
`src/threat_analysis.py` reads the JSON event list. An IP with **more than five** `login_failed` events is flagged as high priority. `api_access_denied` and `request_rate_high` events are listed as medium-priority review items. The sample dataset should flag `203.0.113.10` because it has six failed logins. The IP ranges in the file are reserved for documentation/examples and are not live attacker addresses.

## 6. RBAC matrix
| Role | `/health` | `/transactions` | `/admin/audit` |
|---|---|---|---|
| Viewer | Yes | No | No |
| Analyst | Yes | Yes | No |
| Admin | Yes | Yes | Yes |

The local API's RBAC is application-level role checking. In AWS, use IAM roles and least-privilege policies for KMS/S3 access; do not treat a JWT role claim as an AWS IAM role.

## 7. Evidence to collect before submission
- Terminal output from `python src\threat_analysis.py` and generated `output\threat_analysis.txt`.
- Local API login and a successful `/transactions` request with the analyst token.
- HTTP 401 without a token and HTTP 403 when the Viewer tries `/transactions`.
- If you run AWS steps: KMS key configuration (no sensitive key material), successful encryption/decryption output, and private S3 object properties showing SSE-KMS.
- Add your own screenshots and write the actual result in the report. Do not state AWS deployment or security tests passed unless you ran them.

## 8. Limitations
This is a teaching prototype with simulated data and preconfigured demo accounts. It does not implement a real payment system, live intrusion detection, network firewall deployment, production secrets management, or compliance certification. It is not intended for real financial or personal data.
