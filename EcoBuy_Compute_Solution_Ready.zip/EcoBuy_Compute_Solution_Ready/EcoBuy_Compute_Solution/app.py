from flask import Flask, jsonify
from datetime import datetime, timezone
import os
import socket
import hashlib

app = Flask(__name__)
INSTANCE_ID = os.getenv("INSTANCE_ID", socket.gethostname())

PRODUCTS = [
    {"id": "ECO-101", "name": "Reusable Water Bottle", "price_inr": 399},
    {"id": "ECO-102", "name": "Bamboo Toothbrush Set", "price_inr": 149},
    {"id": "ECO-103", "name": "Recycled Cotton Tote", "price_inr": 249},
    {"id": "ECO-104", "name": "Solar Reading Lamp", "price_inr": 899},
]

@app.get("/")
def home():
    return """
    <!doctype html><html><head><title>EcoBuy</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>body{font:16px Arial;max-width:760px;margin:40px auto;padding:0 18px}
    .card{border:1px solid #ddd;border-radius:10px;padding:16px;margin:10px 0}
    code{background:#f3f3f3;padding:3px}</style></head><body>
    <h1>EcoBuy — Sustainable Shopping</h1>
    <p>Elastic compute prototype for the TCS iON Cloud Development assignment.</p>
    <div id="products">Loading products…</div>
    <p>Served by instance: <code id="instance">checking</code></p>
    <script>
    fetch('/products').then(r=>r.json()).then(d=>{
      document.getElementById('products').innerHTML=d.products.map(p=>
        `<div class="card"><b>${p.name}</b><br>₹${p.price_inr}</div>`).join('');
      document.getElementById('instance').textContent=d.instance_id;
    }).catch(()=>document.getElementById('products').textContent='Could not load products');
    </script></body></html>
    """

@app.get("/health")
def health():
    return jsonify(status="healthy", instance_id=INSTANCE_ID,
                   timestamp=datetime.now(timezone.utc).isoformat()), 200

@app.get("/products")
def products():
    return jsonify(products=PRODUCTS, count=len(PRODUCTS), instance_id=INSTANCE_ID), 200

@app.get("/work")
def work():
    # Small deterministic CPU workload to make the endpoint useful for a demo.
    # Use a controlled test and monitor costs; this is not a denial-of-service tool.
    value = "ecobuy-load-test"
    for _ in range(120000):
        value = hashlib.sha256(value.encode()).hexdigest()
    return jsonify(status="ok", instance_id=INSTANCE_ID, checksum=value[:16]), 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")))
