# EcoBuy Elastic Compute Solution — IHC Cloud Development Assignment 2

**Student:** Nitesh Vishwakarma  
**Course/assignment:** IHC — Cloud Development, Compute Solution, Modular Assignment 2  
**Cloud platform:** Amazon Web Services (AWS)  
**Region:** Asia Pacific (Mumbai), `ap-south-1`  
**Infrastructure as code:** Terraform  
**Application:** Python Flask EcoBuy product catalogue  
**Status of the captured deployment:** Infrastructure was created successfully, but the target-group health checks were failing at the time of evidence capture. This is documented honestly in the report; the deployment must not be described as fully healthy until the verification steps below pass.

## 1. Project overview

EcoBuy is a small e-commerce demonstration application designed to illustrate how a cloud environment can respond to changing traffic. An internet-facing Application Load Balancer (ALB) forwards HTTP requests to Flask applications running on EC2 instances in an Auto Scaling Group (ASG). The ASG spans two Availability Zones, has a minimum and desired capacity of two instances, and a maximum capacity of five. A target-tracking scaling policy targets average ASG CPU utilisation of 70%.

The project includes two generated teaching datasets:
- `datasets/traffic.csv` — synthetic hourly e-commerce traffic.
- `datasets/performance.json` — synthetic CPU and memory observations.

These datasets are illustrative inputs for analysis, not measurements collected from AWS. `scripts/load_test.py` sends real HTTP requests to the deployed app and writes a CSV of observed response results.

## 2. Architecture

1. A user requests the public ALB URL on HTTP port 80.
2. The ALB forwards requests to healthy EC2 targets on TCP port 5000.
3. The Flask application serves `/`, `/products`, `/health`, and `/work`.
4. The target group checks `/health` and expects HTTP 200.
5. The ASG maintains at least two instances across two Availability Zones and can scale up to five.
6. CloudWatch provides a dashboard, a high-CPU alarm, and application log groups. The instance bootstrap attempts to configure the CloudWatch Agent.
7. Terraform provisions the infrastructure reproducibly.

See `report/architecture.svg` for the architecture diagram.

## 3. Repository contents

- `main.tf`, `variables.tf`, `outputs.tf` — AWS infrastructure definitions.
- `terraform.tfvars.example` — example variable values; copy it to `terraform.tfvars` and set your own permitted client IP.
- `user_data.sh` — EC2 startup script that installs and starts the application.
- `app.py` — local copy of the Flask demo application.
- `datasets/` — generated synthetic traffic and performance datasets.
- `scripts/generate_datasets.py` — regenerates the datasets.
- `scripts/load_test.py` — HTTP load-test utility.
- `report/assignment_report.md` — assignment report and current evidence-based status.
- `report/evidence_checklist.md` — evidence capture checklist.
- `.github/workflows/terraform-check.yml` — automated Terraform formatting/validation workflow.

## 4. Requirements

Use Windows PowerShell, Python 3, AWS CLI v2, and Terraform 1.5 or later. The AWS identity configured in the CLI must have permission to create the required EC2, ELB, Auto Scaling, IAM, and CloudWatch resources. Do not put access keys in source code or commit `terraform.tfvars`, state files, or credentials.

Check the tools:

```powershell
python --version
aws --version
terraform -version
aws sts get-caller-identity
```

## 5. Configure and validate

Open PowerShell in the project directory:

```powershell
cd "$HOME\Desktop\EcoBuy_Compute_Solution\EcoBuy_Compute_Solution"
Copy-Item terraform.tfvars.example terraform.tfvars
notepad terraform.tfvars
```

Set `allowed_http_cidr` to your current public IPv4 address followed by `/32` (for example, `203.0.113.10/32` is a documentation-only example and must not be used as your actual address). Keep the region `ap-south-1` unless you intentionally change the region consistently.

Generate the datasets and validate Terraform:

```powershell
python scripts/generate_datasets.py
terraform fmt -recursive
terraform init
terraform validate
terraform plan -out=tfplan
```

Read the plan before applying it. Terraform can create billable resources. If the plan unexpectedly proposes replacement or deletion of resources you need, stop and review the plan.

## 6. Deploy and verify

```powershell
terraform apply tfplan
$url = terraform output -raw app_url
Invoke-RestMethod "$url/health"
Invoke-RestMethod "$url/products"
Start-Process $url
```

A successful health response contains `status` equal to `healthy`. In the AWS Console, open **EC2 → Load Balancing → Target Groups → ecobuy-compute-tg → Targets**. Wait for the initial checks, then confirm both targets show **Healthy**. The EC2 instance state `Running` and system status checks passing do not prove that the Flask application is healthy.

If a target is unhealthy, inspect the reason and the instance startup logs before changing infrastructure:

```powershell
$region = "ap-south-1"
$asg = terraform output -raw autoscaling_group_name
$tg = aws autoscaling describe-auto-scaling-groups `
  --auto-scaling-group-names $asg --region $region `
  --query "AutoScalingGroups[0].TargetGroupARNs[0]" --output text

aws elbv2 describe-target-health `
  --target-group-arn $tg --region $region `
  --query "TargetHealthDescriptions[*].{Instance:Target.Id,Port:Target.Port,State:TargetHealth.State,Reason:TargetHealth.Reason,Description:TargetHealth.Description}" `
  --output table

aws autoscaling describe-auto-scaling-groups `
  --auto-scaling-group-names $asg --region $region `
  --query "AutoScalingGroups[0].Instances[*].{Instance:InstanceId,Lifecycle:LifecycleState,Health:HealthStatus}" `
  --output table
```

For detailed startup errors, select an instance in **EC2 → Instances**, then use **Actions → Monitor and troubleshoot → Get system log**. If Session Manager is configured and available, connect and inspect:

```bash
sudo cloud-init status --long
sudo tail -n 150 /var/log/cloud-init-output.log
sudo systemctl status ecobuy --no-pager
sudo journalctl -u ecobuy -n 100 --no-pager
sudo tail -n 100 /var/log/ecobuy/app-error.log
sudo ss -lntp | grep 5000
curl -i http://127.0.0.1:5000/health
```

The target group uses HTTP port 5000 and `/health`, expecting code 200. Do not claim a successful deployment until the endpoint works locally on the instance and the target group reports healthy.

## 7. Load test and analysis

Start with a small test:

```powershell
python scripts/load_test.py --url "$url/work" --requests 50 --concurrency 5
```

If the app and targets remain healthy, run a larger test:

```powershell
python scripts/load_test.py --url "$url/work" --requests 150 --concurrency 10
```

The test writes `results/load_test_results.csv`. Record actual mean and p95 latency, successful-request percentage, CPU graphs, desired capacity, and ASG activity. A short request burst may not cause CPU-based scale-out; the target-tracking policy reacts to CloudWatch metrics and may take several minutes. Do not claim scale-out unless the ASG Activity history confirms it.

## 8. Monitoring and cost

Open CloudWatch in `ap-south-1` and inspect the dashboard named `ecobuy-compute-dashboard`, the alarm `ecobuy-compute-high-cpu`, and log groups `/ecobuy/app` and `/ecobuy/app-error`. Metric/log delivery depends on successful bootstrap and instance IAM permissions, so verify the data is present before describing it as collected.

Potential costs include EC2 instance runtime, ALB hours and capacity units, public IPv4 addresses, data transfer, and CloudWatch metrics/log ingestion. Estimate the deployment with the AWS Pricing Calculator and state the assumptions and date in the report. The use of public subnets and HTTP is for a learning prototype only; production should use private application subnets, HTTPS with ACM, stronger access controls, and a reviewed network design.

## 9. Evidence and submission

Capture genuine screenshots of:
- Architecture diagram.
- Successful Terraform validation and deployment output.
- EcoBuy home page and `/health` response.
- EC2 instance state and Availability Zones.
- Target group health.
- ASG minimum/desired/maximum capacity and scaling policy.
- CloudWatch dashboard, alarm, and logs.
- Load-test CSV and summary.
- ASG Activity history if scaling occurs.
- Cost estimate and assumptions.

Keep the report concise (the assignment specifies a maximum of four pages) and ensure it matches the evidence actually collected.

## 10. Clean up

After saving evidence and when you no longer need the demo:

```powershell
terraform destroy
```

Review the destroy plan and confirm only when you intend to remove the project resources. Verify in the AWS Console that the EC2, ALB, Auto Scaling, and CloudWatch resources have been removed. Keep the report, datasets, code, and screenshots locally.

