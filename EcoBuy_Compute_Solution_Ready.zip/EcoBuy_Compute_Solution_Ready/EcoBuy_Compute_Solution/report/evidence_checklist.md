# Evidence checklist — capture genuine screenshots

Use clear screenshots with relevant AWS Console page names visible. Do not use mock screenshots or claim a feature worked without proof.

- [ ] Architecture diagram showing client → ALB → EC2 Auto Scaling Group across two AZs → CloudWatch.
- [ ] Terraform `terraform validate` success and deployment output (hide account IDs if preferred).
- [ ] EcoBuy home page in browser showing products and responding instance ID.
- [ ] `/health` JSON response.
- [ ] EC2 console showing at least two running instances in different AZs.
- [ ] Load Balancer listener and target group with healthy targets.
- [ ] ASG configuration: min 2, desired 2, max 5.
- [ ] Target tracking scaling policy: average CPU target 70%.
- [ ] CloudWatch dashboard showing CPU and ALB request count.
- [ ] CloudWatch high CPU alarm and log group/streams.
- [ ] Load-test command, terminal summary, and `results/load_test_results.csv`.
- [ ] ASG Activity history proving scale-out/scale-in if it occurred.
- [ ] Cost estimate with date, region, instance assumptions, and ALB.
- [ ] Resource cleanup (`terraform destroy`) after evidence capture.

Keep each screenshot original and readable. Do not expose access keys, secret values, or sensitive account details.
