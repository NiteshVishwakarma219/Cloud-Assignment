# EcoBuy Elastic Compute Solution
**Student:** Nitesh Vishwakarma  
**Assignment:** IHC — Cloud Development, Compute Solution, Modular Assignment 2  
**Platform:** AWS | **Region:** `ap-south-1` (Asia Pacific—Mumbai)  
**Evidence status:** Initial deployment captured on 15 October 2026; application targets were unhealthy at the time of capture.

## 1. Requirements and architecture (Task 1 — 20 marks)
EcoBuy is an e-commerce prototype intended to handle unpredictable traffic. My design uses an internet-facing Application Load Balancer (ALB) to distribute HTTP requests to a Flask application on EC2 instances in an Auto Scaling Group (ASG). The ASG is configured for a minimum of two instances, desired capacity two, and maximum capacity five across two Availability Zones. A target-tracking policy aims to maintain average ASG CPU utilisation near 70%. A CloudWatch dashboard and high-CPU alarm provide monitoring.

The target group checks HTTP `/health` on port 5000 and expects status code 200. The design diagram is included in `architecture.svg`. The implementation uses public subnets and HTTP for a cost-conscious classroom prototype; a production version should use private application subnets and HTTPS.

## 2. Compute environment and application (Task 2 — 25 marks)
The application is a lightweight Flask catalogue with `/`, `/products`, `/health`, and `/work` routes. EC2 user data installs the runtime, writes the application, configures a systemd service, and attempts to configure the CloudWatch Agent. The instance security group permits port 5000 only from the ALB security group. Terraform provisions the ALB, target group, launch template, ASG, IAM instance profile, scaling policy, CloudWatch dashboard, alarm, and log groups.

The Terraform apply completed with **15 resources added, 0 changed, and 0 destroyed** in the captured terminal output. The AWS Console screenshot showed the ALB `ecobuy-compute-alb` as Active and spanning two Availability Zones. The EC2 screenshot showed two instances Running with 3/3 EC2 status checks passing; other entries were terminated instances from the replacement/launch history.

**Issue identified during verification:** EC2 being Running did not mean the web application was ready. The target-group output showed `Target.FailedHealthChecks` for two instances on port 5000. One earlier instance was `draining` with `Target.DeregistrationInProgress`. Therefore, the initial application deployment cannot yet be marked as healthy. The next diagnostic step is to inspect cloud-init output and the `ecobuy` systemd service, then retest `curl http://127.0.0.1:5000/health` on an instance. This report does not claim that the fix succeeded without new evidence.

## 3. Load balancing, auto-scaling and monitoring (Tasks 3–4; 35 marks)
The ALB listener is configured on port 80 and forwards to target port 5000. The target group health check is `/health`, with HTTP 200 as the accepted response. The ASG uses ELB health checks and a 300-second health-check grace period. Its target-tracking scaling policy uses `ASGAverageCPUUtilization` with a 70% target. The dashboard is configured for ASG CPU and ALB request count. CloudWatch log groups are defined for application output and errors.

| Measurement | Verified result from the captured evidence |
|---|---|
| ALB state | Active |
| Availability Zones | Two |
| EC2 instance state | Two current instances shown as Running |
| EC2 status checks | 3/3 passed for the two Running instances |
| Healthy target count | 0 healthy in the captured target-health output; two targets reported `Target.FailedHealthChecks` |
| Other target state | One older target was draining during deregistration |
| Mean and p95 response time | Not measured yet; run `scripts/load_test.py` after the app is healthy |
| Successful-request percentage | Not measured yet |
| Scale-out event | Not verified; check ASG Activity history after load testing |
| CloudWatch application logs | Must be verified in the log groups before claiming log delivery |

The project includes `traffic.csv` and `performance.json`, both synthetic datasets generated for the assignment. They model hourly traffic and system metrics and must not be presented as real AWS measurements. The load-test script generates an observed results CSV once the application is responding correctly.

## 4. Cost, fault tolerance and resource efficiency (Task 5 — 10 marks)
The ALB distributes traffic only to healthy targets. Running instances across two Availability Zones and maintaining a minimum of two instances is intended to improve resilience. The ASG can add capacity when average CPU remains above its target and scale in when demand falls. Resource tags support cost identification, and CloudWatch log groups have seven-day retention.

The prototype can incur charges for EC2, the ALB, public IPv4 addresses, data transfer, CloudWatch metrics, and logs. A dated estimate should be produced with the AWS Pricing Calculator using the actual region, instance count and runtime, ALB hours, expected data transfer, and monitoring volume. I have not recorded a verified monetary estimate in the current evidence, so no numeric cost is claimed here. Resources should be destroyed after screenshots and test evidence have been saved.

## 5. Strategy, outcomes and conclusion (Task 6 — 10 marks)
My workflow was to define the architecture, provision the resources with Terraform, deploy the Flask application using EC2 user data, inspect the ALB target health, and plan load/monitoring tests. The captured deployment confirms that Terraform created the AWS resources and that the ALB is active across two Availability Zones. It also revealed an application readiness problem: both active targets failed health checks even though the EC2 instances were running and their infrastructure status checks passed.

The next step is to inspect `/var/log/cloud-init-output.log`, `systemctl status ecobuy`, `journalctl -u ecobuy`, and the local `/health` endpoint on an instance. After the endpoint returns HTTP 200 locally, I will verify that both targets become healthy, run the controlled load test, review CloudWatch metrics and ASG Activity history, and calculate cost. These outcomes should be added only after the tests have been performed.

### Evidence index
1. Architecture diagram: `architecture.svg`.
2. Terraform deployment: terminal screenshot showing 15 resources added.
3. ALB: console screenshot showing `ecobuy-compute-alb` Active in two Availability Zones.
4. EC2: console screenshot showing two Running instances with 3/3 status checks.
5. Target health: console/CLI evidence showing `Target.FailedHealthChecks` and one deregistering target.
6. Load-test results: pending successful application health verification.
7. CloudWatch monitoring and cost estimate: verify and capture before final submission.
