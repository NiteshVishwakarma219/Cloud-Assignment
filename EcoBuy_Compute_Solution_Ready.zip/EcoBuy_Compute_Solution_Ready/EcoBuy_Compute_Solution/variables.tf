variable "aws_region" {
  description = "AWS region for the prototype."
  type        = string
  default     = "ap-south-1"
}

variable "project_name" {
  description = "Prefix used to tag resources."
  type        = string
  default     = "ecobuy-compute"
}

variable "instance_type" {
  description = "EC2 instance type. Verify availability and price in your selected region."
  type        = string
  default     = "t3.micro"
}

variable "min_size" {
  type        = number
  default     = 2
}
variable "desired_capacity" {
  type        = number
  default     = 2
}
variable "max_size" {
  type        = number
  default     = 5
}

variable "allowed_http_cidr" {
  description = "CIDR allowed to access the public ALB. For a personal demo, set to your public IP/32 rather than 0.0.0.0/0."
  type        = string
  default     = "0.0.0.0/0"
}
