import csv, json, random
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "datasets"
DATA.mkdir(exist_ok=True)
random.seed(42)

start = datetime(2026, 9, 1, tzinfo=timezone.utc)
traffic_path = DATA / "traffic.csv"
with traffic_path.open("w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["timestamp_utc", "hour", "website_hits", "scenario"])
    for i in range(24 * 14):
        dt = start + timedelta(hours=i)
        base = 250 + (500 if 17 <= dt.hour <= 21 else 0)
        scenario = "normal"
        if dt.weekday() in (4, 5) and 17 <= dt.hour <= 21:
            base += 1000
            scenario = "sale_peak"
        hits = max(20, int(random.gauss(base, max(25, base * 0.12))))
        writer.writerow([dt.isoformat(), dt.hour, hits, scenario])

metrics = []
for i in range(24):
    hour = (start + timedelta(hours=i)).isoformat()
    cpu = round(min(96, max(8, random.gauss(28 + (38 if 17 <= i % 24 <= 21 else 0), 8))), 1)
    memory = round(min(92, max(25, random.gauss(48 + cpu * 0.18, 5))), 1)
    metrics.append({
        "timestamp_utc": hour,
        "instance_label": "synthetic-instance",
        "cpu_utilization_percent": cpu,
        "memory_utilization_percent": memory,
        "requests_per_minute": int(max(5, random.gauss(50 + cpu * 2, 15))),
        "source": "synthetic_demo_data"
    })
(DATA / "performance.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
print(f"Wrote {traffic_path}")
print(f"Wrote {DATA / 'performance.json'}")
print("These are synthetic values, not measurements from AWS.")
