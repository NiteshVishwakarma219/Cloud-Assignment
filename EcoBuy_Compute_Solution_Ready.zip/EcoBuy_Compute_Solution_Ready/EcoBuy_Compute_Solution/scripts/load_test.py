import argparse, csv, statistics, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import HTTPError, URLError

def main():
    parser = argparse.ArgumentParser(description="Controlled concurrent HTTP load test for EcoBuy.")
    parser.add_argument("--url", required=True, help="Endpoint URL, e.g. http://ALB-DNS/work")
    parser.add_argument("--requests", type=int, default=300)
    parser.add_argument("--concurrency", type=int, default=20)
    parser.add_argument("--timeout", type=float, default=15)
    args = parser.parse_args()
    if args.requests < 1 or args.concurrency < 1:
        parser.error("--requests and --concurrency must be positive")

    def one(i):
        start = time.perf_counter()
        status, error = 0, ""
        try:
            req = Request(args.url, headers={"User-Agent": "EcoBuy-Assignment-LoadTest/1.0"})
            with urlopen(req, timeout=args.timeout) as response:
                status = response.status
                response.read()
        except HTTPError as e:
            status, error = e.code, str(e)
        except (URLError, TimeoutError, OSError) as e:
            error = str(e)
        return {
            "request_id": i + 1,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
            "status_code": status,
            "latency_ms": round((time.perf_counter() - start) * 1000, 2),
            "error": error
        }

    started = time.perf_counter()
    rows = []
    with ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        futures = [pool.submit(one, i) for i in range(args.requests)]
        for future in as_completed(futures):
            rows.append(future.result())
    elapsed = time.perf_counter() - started
    rows.sort(key=lambda x: x["request_id"])
    latencies = [r["latency_ms"] for r in rows]
    success = sum(200 <= r["status_code"] < 400 for r in rows)
    out = Path(__file__).resolve().parents[1] / "results" / "load_test_results.csv"
    out.parent.mkdir(exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    ordered = sorted(latencies)
    p95 = ordered[min(len(ordered)-1, int(0.95 * len(ordered)))]
    print(f"URL: {args.url}")
    print(f"Requests: {len(rows)} | Concurrency: {args.concurrency} | Duration: {elapsed:.2f}s")
    print(f"Successful (2xx/3xx): {success}/{len(rows)} ({100*success/len(rows):.1f}%)")
    print(f"Mean latency: {statistics.mean(latencies):.2f} ms | p95 latency: {p95:.2f} ms")
    print(f"Throughput: {len(rows)/elapsed:.2f} requests/sec")
    print(f"Results CSV: {out}")
    print("Use CloudWatch and ASG Activity history to verify whether scaling actually occurred.")

if __name__ == "__main__":
    main()
