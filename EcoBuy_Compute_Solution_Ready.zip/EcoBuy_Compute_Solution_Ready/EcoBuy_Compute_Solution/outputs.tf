output "app_url" {
  description = "Public HTTP URL of the EcoBuy demonstration app."
  value       = "http://${aws_lb.app.dns_name}"
}
output "alb_dns_name" {
  value = aws_lb.app.dns_name
}
output "autoscaling_group_name" {
  value = aws_autoscaling_group.app.name
}
output "cloudwatch_dashboard_name" {
  value = aws_cloudwatch_dashboard.app.dashboard_name
}
output "aws_region" {
  value = var.aws_region
}
