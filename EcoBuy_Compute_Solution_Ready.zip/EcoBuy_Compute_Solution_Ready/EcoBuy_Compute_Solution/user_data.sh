#!/bin/bash
set -euxo pipefail
dnf update -y
dnf install -y python3 python3-pip amazon-cloudwatch-agent
mkdir -p /opt/ecobuy /var/log/ecobuy
cat > /opt/ecobuy/app.py <<'PYAPP'
from flask import Flask, jsonify
from datetime import datetime, timezone
import socket, hashlib
app=Flask(__name__)
instance=socket.gethostname()
products=[
 {"id":"ECO-101","name":"Reusable Water Bottle","price_inr":399},
 {"id":"ECO-102","name":"Bamboo Toothbrush Set","price_inr":149},
 {"id":"ECO-103","name":"Recycled Cotton Tote","price_inr":249},
 {"id":"ECO-104","name":"Solar Reading Lamp","price_inr":899}]
@app.get("/")
def home():
 return """<!doctype html><html><head><title>EcoBuy</title><meta name='viewport' content='width=device-width,initial-scale=1'><style>body{font:16px Arial;max-width:760px;margin:40px auto;padding:0 18px}.card{border:1px solid #ddd;border-radius:10px;padding:16px;margin:10px 0}</style></head><body><h1>EcoBuy — Sustainable Shopping</h1><p>Cloud auto-scaling prototype</p><div id='p'>Loading...</div><p>Instance: <span id='i'>...</span></p><script>fetch('/products').then(r=>r.json()).then(d=>{document.getElementById('p').innerHTML=d.products.map(p=>`<div class="card"><b>${p.name}</b><br>₹${p.price_inr}</div>`).join('');document.getElementById('i').textContent=d.instance_id})</script></body></html>"""
@app.get("/health")
def health():
 return jsonify(status="healthy",instance_id=instance,timestamp=datetime.now(timezone.utc).isoformat()),200
@app.get("/products")
def products_route():
 return jsonify(products=products,count=len(products),instance_id=instance),200
@app.get("/work")
def work():
 value="ecobuy-load-test"
 for _ in range(120000): value=hashlib.sha256(value.encode()).hexdigest()
 return jsonify(status="ok",instance_id=instance,checksum=value[:16]),200
app.run(host="0.0.0.0",port=5000)
PYAPP
python3 -m pip install --break-system-packages Flask==3.1.1
cat > /etc/systemd/system/ecobuy.service <<'SERVICE'
[Unit]
Description=EcoBuy Flask demo
After=network-online.target
[Service]
WorkingDirectory=/opt/ecobuy
ExecStart=/usr/bin/python3 /opt/ecobuy/app.py
Restart=always
RestartSec=3
User=root
StandardOutput=append:/var/log/ecobuy/app.log
StandardError=append:/var/log/ecobuy/app-error.log
[Install]
WantedBy=multi-user.target
SERVICE
cat > /opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json <<'CW'
{
  "agent": {"metrics_collection_interval": 60, "run_as_user": "root"},
  "metrics": {"namespace": "EcoBuy/Compute", "append_dimensions": {"InstanceId": "${aws:InstanceId}"},
    "metrics_collected": {"mem": {"measurement": ["mem_used_percent"], "metrics_collection_interval": 60},
      "disk": {"measurement": ["used_percent"], "resources": ["/"], "metrics_collection_interval": 60}}},
  "logs": {"logs_collected": {"files": {"collect_list": [
    {"file_path": "/var/log/ecobuy/app.log", "log_group_name": "/ecobuy/app", "log_stream_name": "{instance_id}/app"},
    {"file_path": "/var/log/ecobuy/app-error.log", "log_group_name": "/ecobuy/app-error", "log_stream_name": "{instance_id}/error"}
  ]}}}
}
CW
systemctl daemon-reload
systemctl enable --now ecobuy
/opt/aws/amazon-cloudwatch-agent/bin/amazon-cloudwatch-agent-ctl -a fetch-config -m ec2 -c file:/opt/aws/amazon-cloudwatch-agent/etc/amazon-cloudwatch-agent.json -s || true
