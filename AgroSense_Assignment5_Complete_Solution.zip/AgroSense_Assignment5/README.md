# AgroSense Ltd. — Assignment 5: Network and IoT Solution

## Project overview
This project demonstrates an IoT monitoring pipeline for smart agriculture. It includes two created datasets, a sensor simulator, an analysis script for connectivity/latency logs, a local Streamlit dashboard, and optional AWS IoT Core/DynamoDB integration helpers.

**Important status note:** the datasets and local analysis/dashboard code are a demonstration. AWS IoT Core and DynamoDB are not deployed by these files alone. Do not describe cloud resources as deployed unless you configure and test them in your own AWS account.

## Folder structure
- `data/IoT_Sensor_Simulation_Data.csv` — sample sensor readings.
- `data/Cloud_Monitoring_Logs.json` — simulated connectivity and latency events.
- `src/simulate_sensors.py` — generate telemetry locally, optionally publish via MQTT/TLS to AWS IoT Core.
- `src/analyze_monitoring.py` — calculate connectivity and latency summary.
- `src/ingest_dynamodb.py` — optional write of a JSON telemetry item to DynamoDB.
- `src/dashboard.py` — Streamlit visualisation.
- `docs/architecture.png` and `.svg` — cloud topology diagram.
- `docs/Development_Strategy_Report.pdf` — short report.

## Run locally on Windows PowerShell
Open PowerShell in the extracted `AgroSense_Assignment5` folder:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python src\analyze_monitoring.py
python src\simulate_sensors.py --count 20
streamlit run src\dashboard.py
```

Open the local Streamlit URL printed in the terminal. The dashboard reads the sample CSV and will include additional lines appended by the simulator.

## Optional AWS IoT Core MQTT setup
1. Choose a region (example: `ap-south-1`) and create an AWS IoT Thing for each sensor.
2. Create/download each Thing certificate and private key; download Amazon Root CA. Store private keys securely and never commit them to Git.
3. Attach a narrowly scoped IoT policy to each certificate. Start from `config/aws_iot_topic_policy_example.json`, replacing `ACCOUNT_ID` and adapting the topic ARN to the Thing name. Validate policy variables and topic paths in AWS IoT before use.
4. Find the account-specific IoT data endpoint in the AWS IoT console.
5. Publish a test message to `agrosense/<farm_id>/<device_id>/telemetry` using MQTT over TLS on port 8883:

```powershell
python src\simulate_sensors.py --mqtt --count 10 --host YOUR_ENDPOINT --cert device-certificate.pem.crt --key private.pem.key --ca AmazonRootCA1.pem
```

6. In AWS IoT Core, create a message rule for `agrosense/+/+/telemetry` and configure it to write to DynamoDB (or invoke a Lambda function that validates and writes to DynamoDB). Grant only the rule's required write permissions.
7. Create DynamoDB table `AgroSenseTelemetry` with partition key `device_id` (String) and sort key `timestamp` (String). Enable encryption at rest (default AWS-owned key is suitable for a demo) and configure retention/TTL if needed.
8. For direct local DynamoDB testing, save one generated JSON line to a file and run `python src\ingest_dynamodb.py path\to\one-reading.json`. Configure AWS CLI credentials/profile and IAM permissions first.

## Security controls
- MQTT over TLS 1.2+ and per-device X.509 certificates.
- Unique device identity; scoped publish permissions and topic-level least privilege.
- IAM role for ingestion service; no embedded AWS access keys.
- Encryption at rest for database and backups; secure certificate/key storage and rotation.
- Validate message schema, numeric ranges, timestamp and device identity before storage.
- CloudWatch metrics/alarms for disconnected devices, message errors, latency, and unusual message volume.
- Keep logs free of credentials and personal data; apply least privilege and retention rules.

## Sample analysis interpretation
The provided sample monitoring logs include a heartbeat timeout for `sensor-002`, followed by reconnection, and high-latency readings for `sensor-004`. The analysis script computes average/max latency and counts observations over 250 ms. These are simulated data points, not real farm incidents.

## Suggested screenshots for submission
1. `docs/architecture.png` architecture diagram.
2. PowerShell output from `python src\analyze_monitoring.py`.
3. Streamlit dashboard with charts and table.
4. If actually configured: AWS IoT MQTT test publish/subscription, DynamoDB items, and cloud rule configuration. Do not fabricate screenshots or claim an AWS deployment you did not perform.

## Limitations
This is a learning/demo project, not production-ready agricultural control software. A production build should add schema validation, retries/dead-letter handling, time-series retention, monitoring alerts, device provisioning/rotation, infrastructure-as-code, automated tests, and multi-region recovery where justified.
