"""Local Streamlit dashboard for sample and generated AgroSense telemetry."""
import json
from pathlib import Path
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
st.set_page_config(page_title="AgroSense IoT Monitor", layout="wide")
st.title("AgroSense Ltd. — IoT Farm Monitoring")
st.caption("Demonstration dashboard using supplied sample data; it is not a live cloud dashboard until connected to a deployed pipeline.")
base = pd.read_csv(ROOT / "data" / "IoT_Sensor_Simulation_Data.csv")
extra_path = ROOT / "output" / "generated_telemetry.jsonl"
if extra_path.exists():
    extra = []
    for line in extra_path.read_text(encoding="utf-8").splitlines():
        try: extra.append(json.loads(line))
        except json.JSONDecodeError: pass
    if extra: base = pd.concat([base, pd.DataFrame(extra)], ignore_index=True)
base["timestamp"] = pd.to_datetime(base["timestamp"], errors="coerce", utc=True)
logs = json.loads((ROOT / "data" / "Cloud_Monitoring_Logs.json").read_text(encoding="utf-8"))
log_df = pd.DataFrame(logs)
col1, col2, col3, col4 = st.columns(4)
col1.metric("Readings", len(base)); col2.metric("Devices", base.device_id.nunique())
col3.metric("Mean temperature", f"{base.temperature_c.mean():.1f} °C")
col4.metric("Mean soil moisture", f"{base.soil_moisture_pct.mean():.1f}%")
st.subheader("Sensor trends")
st.line_chart(base.sort_values("timestamp").set_index("timestamp")[["temperature_c", "soil_moisture_pct", "humidity_pct"]])
st.subheader("Latest reading by device")
st.dataframe(base.sort_values("timestamp", ascending=False).groupby("device_id", as_index=False).first(), use_container_width=True)
st.subheader("Connectivity and latency")
lat = pd.to_numeric(log_df["latency_ms"], errors="coerce")
st.write(f"Monitoring events: {len(log_df)} | Disconnect events: {(log_df.status == 'disconnected').sum()} | Average observed latency: {lat.mean():.1f} ms")
st.dataframe(log_df, use_container_width=True)
st.warning("Sample data is simulated. Configure AWS IoT Core, certificates, DynamoDB, and an ingestion rule before presenting this as a live deployment.")
