"""Generate realistic demo telemetry and optionally publish to an MQTT broker."""
import argparse, csv, json, random, time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEVICES = [("sensor-001", "farm-north"), ("sensor-002", "farm-north"), ("sensor-003", "farm-east"), ("sensor-004", "farm-east"), ("sensor-005", "farm-south")]

def reading(device_id, farm_id):
    return {"timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"), "device_id": device_id,
            "farm_id": farm_id, "temperature_c": round(random.uniform(22, 34), 1),
            "soil_moisture_pct": round(random.uniform(15, 55), 1), "humidity_pct": round(random.uniform(40, 80), 1),
            "battery_pct": random.randint(65, 100)}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--count", type=int, default=10, help="number of readings to generate")
    p.add_argument("--mqtt", action="store_true", help="publish to configured MQTT broker")
    p.add_argument("--host", default="", help="AWS IoT endpoint hostname")
    p.add_argument("--cert", default="", help="device certificate PEM path")
    p.add_argument("--key", default="", help="device private key PEM path")
    p.add_argument("--ca", default="", help="Amazon Root CA PEM path")
    args = p.parse_args()
    client = None
    if args.mqtt:
        if not all([args.host, args.cert, args.key, args.ca]):
            p.error("--mqtt requires --host, --cert, --key, and --ca")
        try:
            import paho.mqtt.client as mqtt
        except ImportError:
            p.error("Install optional dependency: pip install paho-mqtt")
        client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="agrosense-simulator")
        client.tls_set(ca_certs=args.ca, certfile=args.cert, keyfile=args.key)
        client.connect(args.host, 8883, 60); client.loop_start()
    out = ROOT / "output" / "generated_telemetry.jsonl"
    out.parent.mkdir(exist_ok=True)
    with out.open("a", encoding="utf-8") as f:
        for i in range(args.count):
            device, farm = DEVICES[i % len(DEVICES)]
            data = reading(device, farm); line = json.dumps(data)
            print(line); f.write(line + "\n")
            if client:
                topic = f"agrosense/{farm}/{device}/telemetry"
                info = client.publish(topic, line, qos=1)
                info.wait_for_publish()
            time.sleep(0.2 if client else 0.02)
    if client:
        client.loop_stop(); client.disconnect()
    print(f"Saved readings to {out}")
if __name__ == "__main__": main()
