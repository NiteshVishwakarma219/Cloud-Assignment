"""Summarise device connectivity and latency from sample cloud monitoring logs."""
import json, statistics, csv
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
logs = json.loads((ROOT / "data" / "Cloud_Monitoring_Logs.json").read_text(encoding="utf-8"))
latencies = [x["latency_ms"] for x in logs if isinstance(x.get("latency_ms"), (int, float))]
connected = sum(x.get("status") == "connected" for x in logs)
disconnected = sum(x.get("status") == "disconnected" for x in logs)
reconnects = sum(x.get("event") == "reconnected" for x in logs)
summary = {
 "total_log_events": len(logs), "connected_events": connected, "disconnected_events": disconnected,
 "reconnection_events": reconnects, "latency_samples": len(latencies),
 "average_latency_ms": round(statistics.mean(latencies), 1) if latencies else None,
 "max_latency_ms": max(latencies) if latencies else None,
 "events_over_250ms": sum(x > 250 for x in latencies),
 "interpretation": "Investigate sensor-004 latency above 250 ms and review sensor-002 heartbeat timeout."
}
out = ROOT / "output"; out.mkdir(exist_ok=True)
(out / "monitoring_analysis.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
with (out / "device_status_summary.csv").open("w", newline="", encoding="utf-8") as f:
 w = csv.writer(f); w.writerow(["metric", "value"]); w.writerows(summary.items())
print(json.dumps(summary, indent=2))
