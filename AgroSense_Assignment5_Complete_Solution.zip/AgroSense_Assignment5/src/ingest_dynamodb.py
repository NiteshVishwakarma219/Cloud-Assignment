"""Optional AWS ingestion helper: write one JSON telemetry object to DynamoDB.
Use an IAM role/profile; do not hard-code access keys. This is not run until AWS is configured.
"""
import argparse, json, os
from decimal import Decimal
import boto3

def convert(value):
    if isinstance(value, float): return Decimal(str(value))
    if isinstance(value, dict): return {k: convert(v) for k, v in value.items()}
    if isinstance(value, list): return [convert(v) for v in value]
    return value

def main():
    p = argparse.ArgumentParser(); p.add_argument("payload", help="path to one telemetry JSON object")
    p.add_argument("--table", default=os.getenv("DYNAMODB_TABLE", "AgroSenseTelemetry")); p.add_argument("--region", default=os.getenv("AWS_REGION", "ap-south-1")); a = p.parse_args()
    item = convert(json.loads(open(a.payload, encoding="utf-8").read()))
    if not item.get("device_id") or not item.get("timestamp"):
        raise SystemExit("Payload must contain device_id and timestamp")
    table = boto3.resource("dynamodb", region_name=a.region).Table(a.table)
    table.put_item(Item=item)
    print(f"Stored telemetry for {item['device_id']} at {item['timestamp']} in {a.table}")
if __name__ == "__main__": main()
