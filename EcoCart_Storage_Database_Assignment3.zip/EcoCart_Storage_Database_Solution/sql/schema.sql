CREATE TABLE IF NOT EXISTS customers (
 customer_id BIGINT PRIMARY KEY, full_name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE, city TEXT NOT NULL, created_at DATE NOT NULL
);
CREATE TABLE IF NOT EXISTS products (
 product_id BIGINT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL,
 price NUMERIC(10,2) NOT NULL CHECK (price >= 0), stock INTEGER NOT NULL CHECK (stock >= 0),
 description_key TEXT NOT NULL, image_key TEXT NOT NULL
);
