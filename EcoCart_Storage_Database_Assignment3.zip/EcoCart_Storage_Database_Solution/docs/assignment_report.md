# EcoCart Ltd. — Storage and Database Solution
**IHC – Cloud Development | Assignment 3 | Student: Nitesh Vishwakarma**

## 1. Objective
I designed a cloud storage prototype for EcoCart Ltd. that separates structured catalogue/customer records from unstructured product images and descriptions. PostgreSQL supports relational queries, while Amazon S3 stores files and the database stores the corresponding object keys.

## 2. Architecture
The design uses Amazon RDS for PostgreSQL and a private Amazon S3 bucket in `ap-south-1`. Terraform provisions the resources. Python scripts use psycopg for database operations and Boto3 for object upload, listing and download. The database security group restricts inbound PostgreSQL traffic to a configured client CIDR. S3 blocks public access, enables server-side encryption and versioning; RDS storage encryption and seven-day automated backups are configured. The architecture diagram is in `assets/architecture.svg`.

## 3. Data model and integration
The supplied `products.csv` and `customers.csv` files contain sample structured data. Product records store the S3 keys for their images and descriptions. The asset folders contain three generated catalogue image illustrations and three text descriptions. `upload_objects.py` uploads files to S3; `load_database.py` creates the tables and imports CSV records with parameterized SQL and conflict handling; `query_demo.py` queries PostgreSQL and lists S3 objects; `download_object.py` retrieves one object to the local machine.

## 4. Security, backup and cost
The S3 bucket blocks public access, encrypts objects and enables versioning. RDS storage is encrypted and automated backups are retained for seven days. Database ingress is limited to a specified client IP CIDR rather than opened to everyone. For production, I would place RDS in private subnets, use a private application tier, retrieve credentials from AWS Secrets Manager, use IAM roles, enable deletion protection and consider Multi-AZ RDS where the availability requirement justifies its extra cost.

The lab uses a small RDS instance and sample data. Actual charges depend on region, runtime, database eligibility, storage, backup retention, S3 requests, data transfer and public IPv4 use. I would check the AWS Pricing Calculator before deployment and destroy lab resources after collecting evidence.

## 5. Testing and evidence
The package includes repeatable scripts for object upload, relational ingestion, querying and retrieval. The cloud operations have not been executed as part of preparing this document, so no cloud test is claimed as passed here. After running the project, I will attach genuine screenshots of Terraform validation/deployment, S3 objects, RDS encryption/backup settings, database import counts, SQL query output and successful object download.

## 6. Conclusion
This prototype demonstrates a practical separation of responsibilities: PostgreSQL stores validated relational records and supports SQL queries, while S3 stores product assets. Keeping object keys in product rows connects the two layers. The main considerations are secure access, encryption, repeatable provisioning, test evidence and cloud cost management.
