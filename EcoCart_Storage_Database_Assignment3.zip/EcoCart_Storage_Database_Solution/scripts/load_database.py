import csv
from pathlib import Path
from common import db_connection
root=Path(__file__).resolve().parents[1]
conn=db_connection()
try:
    with conn.cursor() as cur:
        cur.execute('''CREATE TABLE IF NOT EXISTS customers (customer_id BIGINT PRIMARY KEY, full_name TEXT NOT NULL, email TEXT NOT NULL UNIQUE, city TEXT NOT NULL, created_at DATE NOT NULL);
        CREATE TABLE IF NOT EXISTS products (product_id BIGINT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, price NUMERIC(10,2) NOT NULL CHECK(price>=0), stock INTEGER NOT NULL CHECK(stock>=0), description_key TEXT NOT NULL, image_key TEXT NOT NULL);''')
        for filename, table, columns in [('customers.csv','customers',['customer_id','full_name','email','city','created_at']),('products.csv','products',['product_id','name','category','price','stock','description_key','image_key'])]:
            with (root/'data'/filename).open(newline='',encoding='utf-8') as f:
                for row in csv.DictReader(f):
                    names=', '.join(columns); marks=', '.join(['%s']*len(columns)); updates=', '.join(f'{c}=EXCLUDED.{c}' for c in columns[1:])
                    cur.execute(f'INSERT INTO {table} ({names}) VALUES ({marks}) ON CONFLICT ({columns[0]}) DO UPDATE SET {updates}', tuple(row[c] for c in columns))
    conn.commit()
    with conn.cursor() as cur:
        cur.execute('SELECT COUNT(*) FROM products'); products=cur.fetchone()[0]
        cur.execute('SELECT COUNT(*) FROM customers'); customers=cur.fetchone()[0]
    print(f'DATABASE LOAD OK | products={products} | customers={customers}')
finally: conn.close()
