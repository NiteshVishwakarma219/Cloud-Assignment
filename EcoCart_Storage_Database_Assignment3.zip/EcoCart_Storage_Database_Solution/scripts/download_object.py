import argparse
from pathlib import Path
from common import bucket_name, s3_client
p=argparse.ArgumentParser(description='Download a private EcoCart S3 object')
p.add_argument('--key',required=True); p.add_argument('--output',required=True); a=p.parse_args()
dest=Path(a.output); dest.parent.mkdir(parents=True,exist_ok=True)
s3_client().download_file(bucket_name(),a.key,str(dest))
print(f'DOWNLOAD OK | s3://{bucket_name()}/{a.key} -> {dest.resolve()} | {dest.stat().st_size} bytes')
