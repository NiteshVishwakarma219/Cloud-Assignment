import os
import boto3

def bucket_name():
    value = os.getenv('ECART_BUCKET')
    if not value:
        raise SystemExit('Set ECART_BUCKET using the Terraform output command in README.md.')
    return value

def s3_client():
    return boto3.client('s3', region_name=os.getenv('AWS_REGION', 'ap-south-1'))

def db_connection():
    import psycopg
    keys = ['ECART_DB_HOST', 'ECART_DB_NAME', 'ECART_DB_USER', 'ECART_DB_PASSWORD']
    missing = [k for k in keys if not os.getenv(k)]
    if missing:
        raise SystemExit('Missing database environment variables: ' + ', '.join(missing))
    return psycopg.connect(host=os.environ['ECART_DB_HOST'], port=int(os.getenv('ECART_DB_PORT','5432')), dbname=os.environ['ECART_DB_NAME'], user=os.environ['ECART_DB_USER'], password=os.environ['ECART_DB_PASSWORD'], connect_timeout=10, sslmode='require')
