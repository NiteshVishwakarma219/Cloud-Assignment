from common import bucket_name, db_connection, s3_client
conn=db_connection()
try:
    with conn.cursor() as cur:
        cur.execute('SELECT product_id,name,category,price,stock,image_key,description_key FROM products ORDER BY product_id')
        print('PRODUCT QUERY')
        for row in cur.fetchall(): print(row)
        cur.execute('SELECT COUNT(*) FROM customers'); print('CUSTOMER COUNT:',cur.fetchone()[0])
finally: conn.close()
s3=s3_client(); bucket=bucket_name(); count=0
print('S3 OBJECT LIST')
for page in s3.get_paginator('list_objects_v2').paginate(Bucket=bucket):
    for obj in page.get('Contents',[]): print(f"{obj['Key']} | {obj['Size']} bytes"); count+=1
print('S3 OBJECT COUNT:',count)
