from pathlib import Path
from common import bucket_name, s3_client
root = Path(__file__).resolve().parents[1]
s3, bucket, count = s3_client(), bucket_name(), 0
for folder, prefix in [(root/'data/product-assets','product-images'),(root/'data/product-descriptions','product-descriptions')]:
    for path in sorted(folder.iterdir()):
        if path.is_file():
            content_type = 'image/svg+xml' if path.suffix == '.svg' else ('text/plain; charset=utf-8' if path.suffix == '.txt' else 'application/octet-stream')
            s3.upload_file(str(path), bucket, f'{prefix}/{path.name}', ExtraArgs={'ServerSideEncryption':'AES256','ContentType':content_type})
            print(f'UPLOAD OK | s3://{bucket}/{prefix}/{path.name} | {path.stat().st_size} bytes')
            count += 1
print(f'Upload complete: {count} objects.')
