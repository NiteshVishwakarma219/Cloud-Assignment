# EcoCart Ltd. — Storage and Database Solution
**IHC – Cloud Development | Assignment 3 | Student: Nitesh Vishwakarma**

## Overview
This project demonstrates a storage design for an e-commerce catalogue. PostgreSQL stores structured product/customer records; Amazon S3 stores product images and descriptions. Terraform provisions the AWS resources and Python scripts upload objects, import CSV rows, query records, and download an object.

## Included files
- `data/products.csv`, `data/customers.csv`: sample structured data.
- `data/product-assets/`: sample catalogue images.
- `data/product-descriptions/`: sample text descriptions.
- `sql/schema.sql`: relational schema.
- `terraform/`: S3, RDS PostgreSQL, and restricted security group.
- `scripts/`: Boto3 upload/download and PostgreSQL import/query scripts.
- `docs/assignment_report.md`: report.
- `assets/architecture.svg`: architecture diagram.

## Requirements
AWS CLI v2, Terraform 1.5+, Python 3.11+, and an AWS identity permitted to create S3, RDS, and security-group resources. Do not use root access keys or commit credentials.

## Deploy (Windows PowerShell)
1. Configure AWS CLI: `aws configure`, then verify with `aws sts get-caller-identity`.
2. Set your current public IPv4 address as a `/32` CIDR and a strong password (12–41 characters) in the same PowerShell session:
   ```powershell
   $env:TF_VAR_db_client_cidr = "YOUR_PUBLIC_IPV4/32"
   $env:TF_VAR_db_password = Read-Host "Choose a strong database password"
   ```
   Replace `YOUR_PUBLIC_IPV4` with your actual public IPv4 address. Do not use `0.0.0.0/0`.
3. Provision:
   ```powershell
   cd terraform
   terraform init
   terraform fmt -recursive
   terraform validate
   terraform plan -out=tfplan
   terraform apply tfplan
   ```
4. From project root, install dependencies and set connection environment variables using Terraform outputs:
   ```powershell
   cd ..
   python -m venv .venv
   .\.venv\Scripts\Activate.ps1
   pip install -r requirements.txt
   $env:AWS_REGION = "ap-south-1"
   $env:ECART_BUCKET = terraform -chdir=terraform output -raw bucket_name
   $env:ECART_DB_HOST = terraform -chdir=terraform output -raw db_endpoint
   $env:ECART_DB_PORT = "5432"
   $env:ECART_DB_NAME = terraform -chdir=terraform output -raw db_name
   $env:ECART_DB_USER = terraform -chdir=terraform output -raw db_username
   $env:ECART_DB_PASSWORD = $env:TF_VAR_db_password
   ```
5. Run:
   ```powershell
   python scripts/upload_objects.py
   python scripts/load_database.py
   python scripts/query_demo.py
   python scripts/download_object.py --key product-images/product-1001.png --output downloaded-product.png
   ```

## Security and cost
The S3 bucket blocks public access, enables AES-256 server-side encryption and versioning. RDS storage encryption and seven-day backups are enabled. The database security group allows PostgreSQL only from the specified client CIDR. This is a lab setup; production should place RDS in private subnets, use IAM roles and Secrets Manager, enable deletion protection, and consider Multi-AZ. RDS, S3, data transfer and public IPv4 charges may apply. Review AWS pricing before deployment.

## Evidence and cleanup
Capture real screenshots of Terraform validation/apply, S3 objects, RDS encryption/backups, database load output, query output and successful object download. Do not claim tests passed before running them. After saving evidence, run `terraform destroy` from `terraform/` and confirm the plan removes only this lab's resources.
