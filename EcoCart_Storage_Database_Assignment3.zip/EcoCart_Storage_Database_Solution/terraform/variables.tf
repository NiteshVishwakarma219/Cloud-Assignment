variable "aws_region" { type = string; default = "ap-south-1" }
variable "project_name" { type = string; default = "ecocart-storage-db" }
variable "db_client_cidr" { type = string; description = "Your public IPv4 address with /32"; validation { condition = can(cidrnetmask(var.db_client_cidr)); error_message = "Set a valid CIDR such as your public IPv4/32." } }
variable "db_username" { type = string; default = "ecocartadmin" }
variable "db_password" { type = string; sensitive = true; validation { condition = length(var.db_password) >= 12 && length(var.db_password) <= 41; error_message = "Password must be 12–41 characters." } }
