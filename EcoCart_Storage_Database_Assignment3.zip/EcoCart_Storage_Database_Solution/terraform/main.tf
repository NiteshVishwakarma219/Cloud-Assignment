resource "random_id" "suffix" { byte_length = 3 }
data "aws_vpc" "default" { default = true }
data "aws_subnets" "default" { filter { name = "vpc-id"; values = [data.aws_vpc.default.id] } }
resource "aws_s3_bucket" "catalogue" { bucket = "${var.project_name}-${random_id.suffix.hex}"; force_destroy = true; tags = { Project = "EcoCart" } }
resource "aws_s3_bucket_public_access_block" "catalogue" { bucket = aws_s3_bucket.catalogue.id; block_public_acls = true; block_public_policy = true; ignore_public_acls = true; restrict_public_buckets = true }
resource "aws_s3_bucket_server_side_encryption_configuration" "catalogue" { bucket = aws_s3_bucket.catalogue.id; rule { apply_server_side_encryption_by_default { sse_algorithm = "AES256" }; bucket_key_enabled = true } }
resource "aws_s3_bucket_versioning" "catalogue" { bucket = aws_s3_bucket.catalogue.id; versioning_configuration { status = "Enabled" } }
resource "aws_db_subnet_group" "catalogue" { name = "${var.project_name}-subnets-${random_id.suffix.hex}"; subnet_ids = data.aws_subnets.default.ids }
resource "aws_security_group" "postgres" {
 name = "${var.project_name}-postgres-${random_id.suffix.hex}"; description = "PostgreSQL access from configured lab client only"; vpc_id = data.aws_vpc.default.id
 ingress { from_port = 5432; to_port = 5432; protocol = "tcp"; cidr_blocks = [var.db_client_cidr] }
 egress { from_port = 0; to_port = 0; protocol = "-1"; cidr_blocks = ["0.0.0.0/0"] }
}
resource "aws_db_instance" "catalogue" {
 identifier = "${var.project_name}-${random_id.suffix.hex}"; engine = "postgres"; engine_version = "16"; instance_class = "db.t3.micro"
 allocated_storage = 20; max_allocated_storage = 30; storage_type = "gp3"; storage_encrypted = true
 db_name = "ecocart"; username = var.db_username; password = var.db_password; port = 5432
 db_subnet_group_name = aws_db_subnet_group.catalogue.name; vpc_security_group_ids = [aws_security_group.postgres.id]
 publicly_accessible = true; backup_retention_period = 7; copy_tags_to_snapshot = true
 auto_minor_version_upgrade = true; deletion_protection = false; skip_final_snapshot = true; apply_immediately = true
 tags = { Project = "EcoCart" }
}
