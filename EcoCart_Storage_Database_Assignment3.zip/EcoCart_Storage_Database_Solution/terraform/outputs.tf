output "bucket_name" { value = aws_s3_bucket.catalogue.bucket }
output "db_endpoint" { value = aws_db_instance.catalogue.address }
output "db_port" { value = aws_db_instance.catalogue.port }
output "db_name" { value = aws_db_instance.catalogue.db_name }
output "db_username" { value = aws_db_instance.catalogue.username }
